# SideProject_Level1_Task1

Here is my JAVA code for Cyber Email Administration App

The App creates an email ID given User's Firstname, Lastname and Department
The App returns with a random password for the created mail ID
The user can change the password afterwards

The App has a method to show User Info(Name. email ID) and Mailbox Capacity
