# SideProject_Level1_Task2

Here is my Django(python) code for Covid-19 News Aggregator

Here the code scrapes news from two popular News Websites The Times of India and The Indian Express about Covid-19 in India and displays the News Articles on a website
