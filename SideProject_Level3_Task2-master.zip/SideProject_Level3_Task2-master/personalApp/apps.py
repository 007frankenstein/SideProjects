from django.apps import AppConfig


class PersonalappConfig(AppConfig):
    name = 'personalApp'
